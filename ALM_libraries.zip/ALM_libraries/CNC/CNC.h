/*
  CNC.h - Librer�a modificada a partir del Arduino Gcode Interpreter para dise�ar un firmware adecuado para una CNC de dos ejes, en concreto una Grabadora l�ser.

Creada por Guillermo Alonso, Junio 2016.
 En concreto contiene:
	-La asignacion de pines de nuestra placa Arduino.
     	-Los par�metros que definen a nuestra impresora
     	-Y algunas estructuras que emplea nuestro c�digo tanto para identificar los comandos que lleguen por monitor serial como para ejecutar los movimientos.
*/

// Arduino G-code Interpreter
// v1.0 by Mike Ellery - initial software (mellery@gmail.com)
// v1.1 by Zach Hoeken - cleaned up and did lots of tweaks (hoeken@gmail.com)
// v1.2 by Chris Meighan - cleanup / G2&G3 support (cmeighan@gmail.com)
// v1.3 by Zach Hoeken - added thermocouple support and multi-sample temp readings. (hoeken@gmail.com)

#ifndef CNC_h
#define CNC_h
#include "arduino.h"


/****************************************************************************************
* digital i/o pin assignment
*
* this uses the undocumented feature of Arduino - pins 14-19 correspond to analog 0-5
****************************************************************************************/
//cartesian bot pins
#define X_STEP_PIN 6
#define X_DIR_PIN 4 
#define X_ENABLE_PIN 5

#define Y_STEP_PIN 9
#define Y_DIR_PIN 7
#define Y_ENABLE_PIN 8 

// define the parameters of our machine.
#define X_STEPS_PER_INCH 183.74
#define X_STEPS_PER_MM   7.23
#define X_MOTOR_STEPS    1700   //Encontre que 200 pasos equivalen a una vuelta. Efectivamente, aunque mejor sera decir media vuelta
                                //Tras hacer varias pruebas, determine que el numero de pasos que ocupa el eje X es de 1700. Esto equivale a 7,23 pasos/mm, lo que nos da un total de 23,5 cm aprox.
#define Y_STEPS_PER_INCH 183.74 
#define Y_STEPS_PER_MM   7.23
#define Y_MOTOR_STEPS    2060   //Para el eje Y usando la misma filosof�a establecemos 2100 como el n�mero de pasos, que equivale a 28,5 cm aprox

//our maximum feedrates
#define FAST_XY_FEEDRATE 1000.0

// Units in curve section
#define CURVE_SECTION_INCHES 0.019685
#define CURVE_SECTION_MM 0.5

// Set to one if sensor outputs inverting (ie: 1 means open, 0 means closed)
// RepRap opto endstops are *not* inverting.
#define SENSORS_INVERTING 0

#define VELOCIDAD 1700
#define ACEPTAR 2
#define LASER 3
#endif
