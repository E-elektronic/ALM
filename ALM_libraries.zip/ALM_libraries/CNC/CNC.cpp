﻿/*
CNC.h - Librería modificada a partir del Arduino Gcode Interpreter para diseñar un firmware adecuado para una CNC de dos ejes, en concreto una Grabadora láser.

Creada por Guillermo Alonso, Junio 2016.
 En concreto contiene:
	-La asignacion de pines de nuestra placa Arduino.
     	-Los parámetros que definen a nuestra impresora
     	-Y algunas estructuras que emplea nuestro código tanto para identificar los comandos que lleguen por monitor serial como para ejecutar los movimientos
*/

#include "arduino.h"
#include "CNC.h"
